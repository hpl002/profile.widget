# Profile.widget

An Übersicht widget to see your profile picture right in the middle of your desktop.

## Usage
Double click on the `get_profile.sh` file then refresh.
If it says you cannot run it, just open your terminal, `cd` into the folder and run `chmod +x get_profile.sh` and then double click on that file.

## Screenshots
![Full screenshot](https://raw.githubusercontent.com/sammosna/profile.widget/master/screenshot_full.png)